import time
import os
import requests
import speech_recognition as sr
from pydub import AudioSegment
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# --- CONFIGURACIÓN DE FFMPEG ---
ffmpeg_path = r"C:\ffmpeg\bin"
os.environ["PATH"] += os.pathsep + ffmpeg_path
AudioSegment.converter = os.path.join(ffmpeg_path, "ffmpeg.exe")
AudioSegment.ffmpeg = os.path.join(ffmpeg_path, "ffmpeg.exe")
AudioSegment.ffprobe = os.path.join(ffmpeg_path, "ffprobe.exe")

def encontrar_iframe_con_audio(driver):
    """Busca recursivamente el botón de audio."""
    print("   -> Buscando botón de audio en iframes...")
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    for index, iframe in enumerate(iframes):
        try:
            driver.switch_to.frame(iframe)
            if len(driver.find_elements(By.ID, "recaptcha-audio-button")) > 0:
                print(f"   -> ¡Encontrado en iframe #{index}!")
                return True
            driver.switch_to.default_content()
        except:
            driver.switch_to.default_content()
    return False

if __name__ == "__main__":
    
    options = uc.ChromeOptions()
    driver = uc.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        # 1. NAVEGACIÓN
        driver.get("https://procesosjudiciales.funcionjudicial.gob.ec/busqueda-filtros")
        
        print("1. Llenando datos...")
        cedula_input = wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "input[formcontrolname='cedulaDemandado']")
        ))
        cedula_input.send_keys("1850972280") 

        print("2. Clic en BUSCAR...")
        btn_buscar = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "button[aria-label='Enviar formulario']")
        ))
        btn_buscar.click()

        # 2. CAPTCHA - CHECKBOX
        print("3. Activando Captcha...")
        iframe_checkbox = wait.until(EC.visibility_of_element_located(
            (By.XPATH, "//iframe[contains(@src, 'recaptcha')]") 
        ))
        driver.switch_to.frame(iframe_checkbox)
        
        checkbox = wait.until(EC.element_to_be_clickable((By.ID, "recaptcha-anchor")))
        checkbox.click()
        time.sleep(2)
        
        is_checked = checkbox.get_attribute("aria-checked")
        driver.switch_to.default_content()

        if is_checked == "true":
            print(">>> ¡PASE DIRECTO! (Sin audio)")
        else:
            print(">>> Reto visual detectado. Iniciando Audio Bypass...")
            time.sleep(3)
            
            # 3. CLICK EN AUDIO
            if not encontrar_iframe_con_audio(driver):
                raise Exception("No se encontró el botón de audio.")
            
            # (Ya estamos dentro del iframe correcto gracias a la función)
            btn_audio = wait.until(EC.element_to_be_clickable((By.ID, "recaptcha-audio-button")))
            btn_audio.click()
            print("   -> Botón Audio presionado.")
            
            # 4. DESCARGA SEGURA (LA CLAVE DEL ÉXITO)
            try:
                link_descarga = wait.until(EC.presence_of_element_located(
                    (By.CLASS_NAME, "rc-audiochallenge-tdownload-link")
                )).get_attribute("href")
            except:
                raise Exception("Google no dio el enlace (Posible bloqueo temporal).")

            print("   -> Descargando audio autenticado...")
            mp3 = "audio.mp3"
            wav = "audio.wav"
            
            # --- AQUÍ ESTÁ EL CAMBIO IMPORTANTE ---
            # Robamos las cookies y el User-Agent del navegador para dárselos a Python
            headers = {
                "User-Agent": driver.execute_script("return navigator.userAgent")
            }
            cookies = driver.get_cookies()
            session = requests.Session()
            for cookie in cookies:
                session.cookies.set(cookie['name'], cookie['value'])
            
            # Descargamos haciéndonos pasar por el navegador
            response = session.get(link_descarga, headers=headers)
            
            with open(mp3, 'wb') as f:
                f.write(response.content)

            # Verificar si bajó algo real
            if os.path.getsize(mp3) < 2000: # Si pesa menos de 2KB, es un error HTML
                print("   [!!!] ERROR: El archivo descargado es falso o está corrupto.")
                print("   Esto suele pasar si Google detecta la IP. Reintenta más tarde.")
                raise Exception("Archivo de audio inválido")

            # Conversión
            print("   -> Convirtiendo con FFmpeg...")
            sound = AudioSegment.from_mp3(mp3)
            sound.export(wav, format="wav")

            # Transcripción
            print("   -> Transcribiendo...")
            recognizer = sr.Recognizer()
            with sr.AudioFile(wav) as source:
                audio_data = recognizer.record(source)
                texto = recognizer.recognize_google(audio_data, language="en-US")
            
            print(f"   -> CÓDIGO DESCIFRADO: {texto}")

            # Enviar
            driver.find_element(By.ID, "audio-response").send_keys(texto)
            time.sleep(1)
            driver.find_element(By.ID, "recaptcha-verify-button").click()
            print("   -> Verificación enviada.")
            
            driver.switch_to.default_content()
            
            # Limpieza
            try:
                os.remove(mp3)
                os.remove(wav)
            except: pass

        # 5. FINALIZAR
        print("Esperando botón BUSCAR final...")
        btn_buscar_final = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "button[aria-label='Enviar formulario']")
        ))
        time.sleep(2)
        btn_buscar_final.click()
        print("\n¡ÉXITO! Búsqueda completada.\n")
        
        time.sleep(100) # Mantener abierto para ver resultados

    except Exception as e:
        print(f"\nERROR: {e}")