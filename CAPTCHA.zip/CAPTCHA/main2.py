import time
import os
import base64
import speech_recognition as sr
from pydub import AudioSegment
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# --- CONFIGURACIÓN DE RUTAS ---
# Aseguramos que Python sepa dónde está todo
ffmpeg_path = r"C:\ffmpeg\bin"
os.environ["PATH"] += os.pathsep + ffmpeg_path
AudioSegment.converter = os.path.join(ffmpeg_path, "ffmpeg.exe")
AudioSegment.ffmpeg = os.path.join(ffmpeg_path, "ffmpeg.exe")
AudioSegment.ffprobe = os.path.join(ffmpeg_path, "ffprobe.exe")

def encontrar_iframe_con_audio(driver):
    """Busca recursivamente el botón de audio."""
    print("   -> Buscando botón de audio en iframes...")
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    for index, iframe in enumerate(iframes):
        try:
            driver.switch_to.frame(iframe)
            if len(driver.find_elements(By.ID, "recaptcha-audio-button")) > 0:
                print(f"   -> ¡Encontrado en iframe #{index}!")
                return True
            driver.switch_to.default_content()
        except:
            driver.switch_to.default_content()
    return False

if __name__ == "__main__":
    
    options = uc.ChromeOptions()
    # options.add_argument("--headless") # No activar headless para evitar detección
    
    driver = uc.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        # 1. NAVEGACIÓN
        driver.get("https://procesosjudiciales.funcionjudicial.gob.ec/busqueda-filtros")
        
        print("1. Llenando datos...")
        cedula_input = wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "input[formcontrolname='cedulaDemandado']")
        ))
        cedula_input.send_keys("0802011379") 

        print("2. Clic en BUSCAR...")
        btn_buscar = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "button[aria-label='Enviar formulario']")
        ))
        btn_buscar.click()

        # 2. CAPTCHA
        print("3. Activando Captcha...")
        iframe_checkbox = wait.until(EC.visibility_of_element_located(
            (By.XPATH, "//iframe[contains(@src, 'recaptcha')]") 
        ))
        driver.switch_to.frame(iframe_checkbox)
        
        checkbox = wait.until(EC.element_to_be_clickable((By.ID, "recaptcha-anchor")))
        checkbox.click()
        time.sleep(2)
        
        is_checked = checkbox.get_attribute("aria-checked")
        driver.switch_to.default_content()

        if is_checked == "true":
            print(">>> ¡PASE DIRECTO! (Sin audio)")
        else:
            print(">>> Reto visual detectado. Iniciando Audio Bypass...")
            time.sleep(3)
            
            # 3. CLICK EN AUDIO
            if not encontrar_iframe_con_audio(driver):
                raise Exception("No se encontró el botón de audio.")
            
            btn_audio = wait.until(EC.element_to_be_clickable((By.ID, "recaptcha-audio-button")))
            btn_audio.click()
            print("   -> Botón Audio presionado.")
            
            # 4. DESCARGA VÍA JAVASCRIPT (NUEVO MÉTODO)
            try:
                link_descarga = wait.until(EC.presence_of_element_located(
                    (By.CLASS_NAME, "rc-audiochallenge-tdownload-link")
                )).get_attribute("href")
            except:
                raise Exception("Google no mostró el enlace (IP BLOQUEADA TEMPORALMENTE).")

            print("   -> Descargando audio internamente (JavaScript)...")
            
            # Script mágico: El navegador descarga el archivo y nos da el contenido en Base64
            # Esto evita usar 'requests' externo y burla la seguridad básica
            js_download = """
                var uri = arguments[0];
                var callback = arguments[1];
                var xhr = new XMLHttpRequest();
                xhr.open('GET', uri, true);
                xhr.responseType = 'arraybuffer';
                xhr.onload = function(e) {
                if (this.status == 200) {
                    var uInt8Array = new Uint8Array(this.response);
                    var i = uInt8Array.length;
                    var binaryString = new Array(i);
                    while (i--) {
                        binaryString[i] = String.fromCharCode(uInt8Array[i]);
                    }
                    var data = binaryString.join('');
                    var base64 = window.btoa(data);
                    callback(base64);
                } else {
                    callback("ERROR");
                }
                };
                xhr.send();
            """
            
            # Ejecutamos el script y esperamos el resultado
            base64_audio = driver.execute_async_script(js_download, link_descarga)
            
            if base64_audio == "ERROR" or not base64_audio:
                print("   [!!!] FALLO CRÍTICO: Google rechazó la conexión interna.")
                print("   [!!!] TU IP ESTÁ QUEMADA. Usa datos del celular ahora mismo.")
                raise Exception("Bloqueo de IP confirmado.")

            # Guardar el archivo decodificado
            mp3 = "audio.mp3"
            wav = "audio.wav"
            
            with open(mp3, "wb") as f:
                f.write(base64.b64decode(base64_audio))

            # Verificar tamaño
            if os.path.getsize(mp3) < 1000:
                raise Exception("El audio descargado está vacío o corrupto.")

            # Conversión
            print("   -> Convirtiendo...")
            sound = AudioSegment.from_mp3(mp3)
            sound.export(wav, format="wav")

            # Transcripción
            print("   -> Transcribiendo...")
            recognizer = sr.Recognizer()
            with sr.AudioFile(wav) as source:
                audio_data = recognizer.record(source)
                texto = recognizer.recognize_google(audio_data, language="en-US")
            
            print(f"   -> CÓDIGO DESCIFRADO: {texto}")

            # Enviar
            driver.find_element(By.ID, "audio-response").send_keys(texto)
            time.sleep(1)
            driver.find_element(By.ID, "recaptcha-verify-button").click()
            print("   -> Verificación enviada.")
            
            driver.switch_to.default_content()
            
            # Limpieza
            try:
                os.remove(mp3)
                os.remove(wav)
            except: pass

        # 5. FINALIZAR
        print("Esperando botón BUSCAR final...")
        btn_buscar_final = wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, "button[aria-label='Enviar formulario']")
        ))
        time.sleep(2)
        btn_buscar_final.click()
        print("\n¡ÉXITO TOTAL! Búsqueda completada.\n")
        
        time.sleep(100) 

    except Exception as e:
        print(f"\nERROR: {e}")