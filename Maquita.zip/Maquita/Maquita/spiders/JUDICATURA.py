import scrapy
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

class JudicaturaSpider(scrapy.Spider):
    name = "JUDICATURA"
    allowed_domains = ["procesosjudiciales.funcionjudicial.gob.ec"]
    start_urls = ["https://procesosjudiciales.funcionjudicial.gob.ec/busqueda-filtros"]

    def __init__(self, cedula=None, *args, **kwargs):
        """
        Recibe el argumento 'cedula' desde la línea de comandos o API.
        Ejemplo: scrapy crawl JUDICATURA -a cedula=1715...
        """
        super(JudicaturaSpider, self).__init__(*args, **kwargs)
        self.cedula_objetivo = cedula
        
        # Configuración del Navegador
        options = webdriver.ChromeOptions()
        options.add_argument("--start-maximized")
        options.add_argument("--ignore-certificate-errors")
        # options.add_argument("--headless") # NO ACTIVAR ESTO (necesitas ver el captcha)
        
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    def parse(self, response):
        self.driver.get(response.url)
        # Tiempo generoso (60s) para asegurar carga lenta
        wait = WebDriverWait(self.driver, 60)

        try:
            # --- PASO 1: INPUT DE CÉDULA ---
            print(f">>> [1/4] BUSCANDO INPUT...")
            input_cedula = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'input[formcontrolname="cedulaDemandado"]')))
            
            # Lógica: Si la API mandó cédula, úsala. Si no, usa la de prueba.
            valor_a_buscar = self.cedula_objetivo if self.cedula_objetivo else "0802011379"
            
            input_cedula.send_keys(valor_a_buscar)
            print(f">>> CÉDULA INGRESADA: {valor_a_buscar}")
            
            # --- PASO 2: PAUSA MANUAL (EL MOMENTO CYBORG) ---
            print("\n" + "!"*60)
            print("⚠️  ACCIÓN HUMANA REQUERIDA ⚠️")
            print("1. Ve a la ventana de Chrome.")
            print("2. Resuelve el Captcha ('No soy un robot').")
            print("3. Dale click al botón BUSCAR.")
            print("4. Espera a que aparezcan los resultados azules.")
            print("-" * 30)
            input(">>> Cuando veas los datos en pantalla, PRESIONA ENTER AQUÍ...")
            print("!"*60 + "\n")

            # --- PASO 3: EXTRACCIÓN DE DATOS ---
            print(">>> [3/4] LEYENDO RESULTADOS...")
            
            # Buscamos directamente las filas con la clase correcta
            filas = self.driver.find_elements(By.CSS_SELECTOR, "div.causa-individual")
            
            print(f">>> SISTEMA: Se detectaron {len(filas)} procesos judiciales.")

            # Validación de seguridad: Si está vacío, imprimimos alerta
            if len(filas) == 0:
                print("⚠️ ALERTA: No se encontraron filas. ¿Resolviste el captcha correctamente?")
                try:
                    # Intento de ver si hay mensaje de 'No se encontraron resultados'
                    msg = self.driver.find_element(By.TAG_NAME, "mat-card-content").text
                    print(f"Mensaje en web: {msg}")
                except:
                    pass

            for fila in filas:
                try:
                    # Extracción usando los selectores DIV que validamos
                    item = {
                        'fecha_ingreso': fila.find_element(By.CSS_SELECTOR, "div.fecha").text,
                        'numero_proceso': fila.find_element(By.CSS_SELECTOR, "div.numero-proceso").text,
                        'accion_infraccion': fila.find_element(By.CSS_SELECTOR, "div.accion-infraccion").text,
                        'detalle': "Ver Carpeta" # El detalle suele ser un icono, ponemos texto fijo o extraemos href si quieres
                    }
                    
                    # Intentamos sacar el link de la carpeta si existe
                    try:
                        link = fila.find_element(By.CSS_SELECTOR, "a[href*='movimientos']").get_attribute("href")
                        item['link_detalle'] = link
                    except:
                        item['link_detalle'] = "No disponible"

                    yield item
                    print(f"   -> Procesado: {item['numero_proceso']}")

                except Exception as e:
                    print(f"   -> Error leyendo una fila específica: {e}")

        except Exception as e:
            print(f"❌ ERROR CRÍTICO EN EL SCRAPER: {e}")
        
        # --- PASO 4: CIERRE ---
        print(">>> [4/4] CERRANDO NAVEGADOR...")
        # Pequeña pausa para asegurar que el archivo se escriba bien antes de matar el proceso
        time.sleep(2)
        self.driver.quit()