from fastapi import FastAPI
import subprocess
import os
import json

app = FastAPI()

@app.get("/")
def home():
    return {"mensaje": "API Judicial Activa. Usa /buscar/{cedula} para consultar."}

@app.get("/buscar/{cedula}")
def buscar_procesos(cedula: str):
    """
    Ejecuta el scraper pasando la cédula como argumento.
    """
    archivo_salida = "resultados.json"
    
    # 1. Limpieza previa
    if os.path.exists(archivo_salida):
        os.remove(archivo_salida)

    try:
        print(f"--- INICIANDO BÚSQUEDA PARA: {cedula} ---")
        
        # 2. Ejecutar Scrapy pasando el argumento '-a cedula=XXXX'
        # Esto le envía el dato al __init__ de la araña
        comando = [
            "scrapy", "crawl", "JUDICATURA", 
            "-a", f"cedula={cedula}", 
            "-O", archivo_salida
        ]
        
        # check=True lanzará error si el scraper falla
        subprocess.run(comando, check=True)

        # 3. Leer resultados
        if os.path.exists(archivo_salida):
            with open(archivo_salida, "r", encoding="utf-8") as f:
                datos = json.load(f)
            
            # Devolvemos JSON con metadata útil
            return {
                "estado": "exito",
                "cedula_consultada": cedula,
                "total_resultados": len(datos),
                "datos": datos
            }
        else:
            return {"estado": "sin_datos", "mensaje": "El scraper terminó pero no generó archivo (¿Quizás 0 resultados?)."}

    except Exception as e:
        return {"estado": "error", "detalle": str(e)}